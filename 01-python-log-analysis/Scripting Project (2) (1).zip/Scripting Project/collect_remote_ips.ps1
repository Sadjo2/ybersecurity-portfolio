# Output file names
param(
    [string]$OutJson = "ps_remote_ips.json",
    [string]$OutCsv  = "ps_remote_ips.csv"
)

# Basic host information
$hostInfo = [pscustomobject]@{
    ComputerName = $env:COMPUTERNAME
    UserName     = $env:USERNAME
    TimestampUtc = (Get-Date).ToUniversalTime().ToString("o")
}

# Collect established TCP connections using netstat
function Get-RemoteConnections {
    param(
        [string]$State = "ESTABLISHED"
    )

    netstat -ano -p tcp |
        Select-String $State |
        ForEach-Object {
            $parts = ($_.Line.Trim() -split "\s+")

            if ($parts.Count -ge 5) {
                $localParts = $parts[1] -split ":"
                $remoteParts = $parts[2] -split ":"

                [pscustomobject]@{
                    LocalAddress  = ($localParts[0..($localParts.Count - 2)] -join ":")
                    LocalPort     = $localParts[-1]
                    RemoteAddress = ($remoteParts[0..($remoteParts.Count - 2)] -join ":")
                    RemotePort    = $remoteParts[-1]
                    OwningProcess = [int]$parts[4]
                }
            }
        } |
        Where-Object {
            $_.RemoteAddress -and
            $_.RemoteAddress -ne "0.0.0.0" -and
            $_.RemoteAddress -ne "::"
        } |
        Sort-Object RemoteAddress, RemotePort
}

# Get a readable process name from the PID
function Get-ProcessNameFromId {
    param(
        [int]$ProcessId
    )

    try {
        return (Get-Process -Id $ProcessId -ErrorAction Stop).ProcessName
    }
    catch {
        return "UNKNOWN"
    }
}

$connections = Get-RemoteConnections

# Add the process name to each connection
$enrichedConnections = foreach ($c in $connections) {
    $processName = Get-ProcessNameFromId -ProcessId $c.OwningProcess

    [pscustomobject]@{
        RemoteIP    = $c.RemoteAddress
        RemotePort  = $c.RemotePort
        LocalIP     = $c.LocalAddress
        LocalPort   = $c.LocalPort
        PID         = $c.OwningProcess
        ProcessName = $processName
    }
}

# Output JSON and CSV for the Python analysis stage
$outputObject = [pscustomobject]@{
    Host        = $hostInfo
    Connections = $enrichedConnections
}

$outputObject |
    ConvertTo-Json -Depth 4 |
    Out-File -Encoding UTF8 $OutJson

$enrichedConnections |
    Export-Csv -NoTypeInformation -Encoding UTF8 $OutCsv

Write-Host "Connection collection complete."
Write-Host "JSON written to:" $OutJson
Write-Host "CSV written to:" $OutCsv
Write-Host "Unique remote IPs found:" (
    ($enrichedConnections.RemoteIP | Sort-Object -Unique).Count
)
