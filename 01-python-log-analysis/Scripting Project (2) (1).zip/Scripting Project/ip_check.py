import csv
import json
import os
import time
import ipaddress
import requests

fileIn = "ps_remote_ips.json"
csvOut = "connection_audit_report.csv"

API_KEY = os.getenv("ABUSEIPDB_API_KEY")

if not API_KEY:
    raise SystemExit("Missing ABUSEIPDB_API_KEY environment variable. Set it in PowerShell first.")

# Ports that may deserve extra attention during a connection audit
WATCH_PORTS = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    3389: "RDP",
    4444: "Common reverse shell port",
    5900: "VNC"
}

def public_ip_checker(ip: str) -> bool:
    try:
        return ipaddress.ip_address(ip).is_global
    except ValueError:
        return False

def risk_level(score: int, watched_port: bool) -> str:
    if score >= 75:
        return "High"
    if score >= 25 or watched_port:
        return "Medium"
    return "Low"

with open(fileIn, "r", encoding="utf-8-sig") as f:
    data = json.load(f)

# Keep one entry per remote IP/port/process combination
connections = []
seen = set()

for c in data.get("Connections", []):
    ip = str(c.get("RemoteIP", "")).strip()
    port = c.get("RemotePort")
    process_name = str(c.get("ProcessName", "UNKNOWN")).strip() or "UNKNOWN"

    key = (ip, port, process_name)

    if ip and key not in seen:
        seen.add(key)
        connections.append({
            "ip": ip,
            "port": port,
            "process": process_name
        })

rows = []
flagged = 0
threshold = 25
max_age = 100

for item in connections:
    ip = item["ip"]
    port = item["port"]
    process_name = item["process"]

    if not public_ip_checker(ip):
        continue

    try:
        r = requests.get(
            "https://api.abuseipdb.com/api/v2/check",
            headers={"Key": API_KEY, "Accept": "application/json"},
            params={"ipAddress": ip, "maxAgeInDays": str(max_age)},
            timeout=15,
        )
        r.raise_for_status()

        d = r.json().get("data", {}) or {}
        score = int(d.get("abuseConfidenceScore") or 0)

        watched_port = port in WATCH_PORTS
        level = risk_level(score, watched_port)

        reasons = []
        if score >= threshold:
            reasons.append(f"AbuseIPDB score {score}")
        if watched_port:
            reasons.append(f"Watched port {port} ({WATCH_PORTS[port]})")
        if not reasons:
            reasons.append("No obvious indicator")

        is_flagged = level in ("Medium", "High")
        if is_flagged:
            flagged += 1

        rows.append({
            "process": process_name,
            "remote_ip": ip,
            "remote_port": port,
            "abuse_score": score,
            "total_reports": d.get("totalReports"),
            "country": d.get("countryCode"),
            "risk_level": level,
            "reason": "; ".join(reasons),
            "flagged": is_flagged,
        })

        time.sleep(1)

    except Exception as e:
        rows.append({
            "process": process_name,
            "remote_ip": ip,
            "remote_port": port,
            "abuse_score": "",
            "total_reports": "",
            "country": "",
            "risk_level": "Unknown",
            "reason": "API check failed",
            "flagged": False,
            "error": str(e),
        })

fieldnames = [
    "process",
    "remote_ip",
    "remote_port",
    "abuse_score",
    "total_reports",
    "country",
    "risk_level",
    "reason",
    "flagged",
    "error",
]

with open(csvOut, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fieldnames)
    w.writeheader()
    w.writerows(rows)

print(f"Connection records found: {len(connections)}")
print(f"Public connections checked: {len(rows)}")
print(f"Connections needing attention: {flagged}")
print(f"Wrote: {csvOut}")
